
const description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed reiciendis odit magni? Quam error eum beatae mollitia nihil earum quas deleniti. Laborum voluptas quod tempora culpa dolore deleniti mollitia earum?"
export const data = [
    {
        name: "sprite",
        description: description,
        images: ["sprite_1.jpg","sprite_2.jpg"]
    },
    {
        name: "pepsi",
        description: description,
        images: ["pepsi_1.jpg","pepsi_2.jpg"]
    },
    {
        name: "fanta",
        description: description,
        images: ["fanta_1.jpg","fanta_2.jpg"]
    },
    {
        name: "banana republic",
        description: description,
        images: ["bananRepublic_1.jpg","bananaRepublic_2.jpg"]
    }
]

