const fonts = {
    body:"Arial",
    heading:" Arial",
}

export default fonts