import {Box} from "@chakra-ui/react";
import Order from "./Order";

 const Orders = ()=>{
    return(
    <>
        <Order/>
    </>
    )
}

export default Orders;