import {Box} from "@chakra-ui/react";


const Order = ({})=>{
    return(
        <Box bg={"#c60000"} minHeight={"100px"}>
            ORDER
        </Box>
    )
}

export default Order;