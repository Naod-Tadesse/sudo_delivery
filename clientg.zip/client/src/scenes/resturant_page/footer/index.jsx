import {Box,Text} from "@chakra-ui/react"

const Footer = ()=>{
    return(
        <Box height={"100%"} bg={"sudoRed.900"} textAlign={"center"} color={"cotton"} padding={"10px"}>
            <Text fontSize={"15px"}>here you see a footer</Text>
        </Box>
    )
}

export default Footer;